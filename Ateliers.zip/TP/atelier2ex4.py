#l'intersection de deux Sets et supprimez ces éléments du premier Set
set1={23, 42, 65, 57, 78, 83, 29}
set2={57, 83, 29, 67, 73, 43, 48}
set1.intersection(set2)
print( "l'intersection des 2 sets:", set1.intersection(set2))
set1 = set1 - set1.intersection(set2)
print("le nouveau set réduit:", set1)
