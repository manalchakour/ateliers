# un programme qui permet de trouver la fréquence d’un caractère dans une chaîne.
from collections import Counter
str = 'BIBLIOTHEQUE'
frequence = Counter(str)
for (key, value) in frequence.items():
    print("Nombre de fréquence de ", key, " est : ", value)


