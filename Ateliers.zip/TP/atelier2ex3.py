#un programme pour itérer une liste donnée et compter l'occurrence de chaque élément et créer un dictionnaire pour montrer le nombre de chaque élément.
l = [2, 5, 2, 13, 1, 2, 15, 13]
for x in l:  #parcourir la liste
  print(x)   #affichage de tous les éléments de la liste
from collections import Counter
Counter(l)
print("les occurences de chaque élément:",Counter(l))

