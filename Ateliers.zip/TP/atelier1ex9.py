#une fonction qui cherche un élément dans une matrice puis renvoi sa position « i,j »
M= [[3,1,5],[9,8,-1],[10,12,2]]    #Création d'une matrice de dimension (3, 3)
print("La matrice donné est:", M)   #Afficher la matrice A
n=len(M)                #nb de lignes
m=len(M[0])             #nb de colomnes
for i in range(n):    #parcourir les lignes
    for j in range(m): #parcourir les colomnes
        i=int(input("entrer i:"))
        j=int(input("entrer j:"))
        print("l'élément cherché est:",M[i][j]) #l'élément d'indice i et j donnés par l'utilisateur
        pos=[i][j]
        print("position",pos)