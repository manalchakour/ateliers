# un programme qui permet d'inverser les lettres d’une chaîne de caractères.
def inverse(s):
    inv = s[::-1] #la chaine de caractère sera inverser du dernier caractère au premier
    return inv
n=(input("entrer une str:"))
print("l'inverse de ",n," est:",inverse(n))
