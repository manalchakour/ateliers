#Itérer une liste donnée et vérifier si un élément donné existe en tant que valeur de clé dans un dictionnaire. Sinon, supprimez-le de la liste
L = [47, 64, 69, 37, 76, 83, 95, 97]
dic = {47:'Yassine', 69:'Imane', 76:'Mohammed', 97:'Abir'}
for key in L: #parcourir la liste
    if key in dic: #parcourir le dictionnaire
        A = [key for key in dic] #si la clé qui est dans le dic appartient aussi à la liste, elle s'affiche
print(A)