#un programme qui permet de compter les chiffres d'un nombre donné en utilisant la récursivité.
def compte(x):
    if (x < 10):
        return 1  # ex 9 c'est qu'un seul chiffre
    else:
        return 1 + compte(x / 10) 
N = int(input("Entrer un nombre:"))
print("le nombre totale de chiffre ", N, " est:", compte(N))