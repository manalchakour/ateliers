#Diviser la liste en 3 morceaux égaux et inverser chaque morceau
list=[24, 1, 17, 3, 5, 7, 87, 65, 2]
print("notre liste:",list)
n=3
output=[list[i:i + n] for i in range(0, len(list), n)]
print("la liste divisée:", output)
output.reverse()
print("la liste inversé",output)

















