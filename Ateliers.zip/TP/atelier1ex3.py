#un programme qui permet de calculer la somme des nombres de 1 à n en utilisant la récursivité.
def somme(n):
    if n==0:
        return 1  #la somme de 0 à 1 est égale à 1
    else:
        return n+somme(n-1)
nb=int(input("Enter the number:"))
print("la somme des nombres de 1 à ",nb," est:",somme(nb))