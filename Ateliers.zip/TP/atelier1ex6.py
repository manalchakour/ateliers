#trier un tableau selon les algorithmes : tri a bulle, tri par sélection et tri par insertion.
tab = [12,4,76,8,1,66,13] #exemple d'un tableau
#tri à bulle
def tri_bulle(tab):
    n = len(tab)
    for i in range(n):
        for j in range(0, n - i - 1):
            if tab[j] > tab[j + 1]:
                tab[j], tab[j + 1] = tab[j + 1], tab[j] # on inverse si on trouve élement plus grand qu'au suivant
tri_bulle(tab)
print("Le tableau trié à bulle est:")
for i in range(len(tab)):
    print("%d" % tab[i])
#tri par selection
def tri_sel(tab):
    for i in range(len(tab)):
        min = i   # on cherche le min
        for j in range(i + 1, len(tab)):
            if tab[min] > tab[j]:
                min = j #la position du plus petit element du tableau prend la place du plus grand
        tmp = tab[i]
        tab[i] = tab[min]
        tab[min] = tmp
    return tab
tri_sel(tab)
print("Le tableau trié par selection est:")
for i in range(len(tab)):
    print("%d" % tab[i])
#tri par insertion
def tri_ins(t):
  for k in range(1,len(t)):
     temp=t[k]
     j=k
     while j>0 and temp<t[j-1]:
       t[j]=t[j-1]
       j-=1
     t[j]=temp
  return t
tri_ins(tab)
print ("Le tableau trié par insertion est:")
for i in range(len(tab)):
    print ("%d" % tab[i])