#Étant donné deux listes, l1 et l2, écrivez un programme pour créer une troisième liste l3 en choisissant un élément d'indice impair dans la liste l1 et des éléments d'indice pair dans la liste l2.
l1=[1,2,3,4,5,6]
l2=[7,8,9,10,11,12]
for indice, element in enumerate(l1):
    if indice%2!=0:
        print(element)
        l1=element
for indice, element in enumerate(l2):
    if indice%2==0:
        print(element)
        l2=element

l3=[l1]+[l2]
print([l3])