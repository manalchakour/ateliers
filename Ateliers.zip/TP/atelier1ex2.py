#un programme qui permet de convertir le nombre décimal en nombre binaire
def conversion(n):
    if n==1:
        return 1 #1 en décimale est égale 1 en binaire
    elif n > 1:
        conversion(n//2)
    print(n%2 ,end='') #le reste de la division totale donne le nombre en binaire
nbr=int(input("ENTRER UN NOMBRE DECIMAL A CONVERTIR:"))
conversion(nbr)