#programme qui calcule la somme des séries 1! / 1 + 2! / 2 + 3! /3 + 4! / 4 + 5! / 5
def factorielle(n):
    if n==1:
        return 1
    else:
        return n*factorielle(n-1)
som=0
n=int(input("enter the number:"))
for i in range(1,n+1):
  som += factorielle(i)/i
print("la somme de la série:",som)
